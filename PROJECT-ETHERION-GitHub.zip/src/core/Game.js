import * as THREE from 'three';
import { createWorld } from '../world/World.js';
import { createPlayer, updatePlayer } from '../character/Player.js';
import { CombatSystem } from '../combat/CombatSystem.js';
import { Enemy } from '../enemies/Enemy.js';
import { HUD } from '../ui/HUD.js';

export class Game {
  constructor(){
    this.scene=new THREE.Scene();
    this.scene.background=new THREE.Color(0x91b9c9);
    this.scene.fog=new THREE.Fog(0x91b9c9,45,180);
    this.camera=new THREE.PerspectiveCamera( sixty(),innerWidth/innerHeight,.1,400);
    this.renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
    this.renderer.setSize(innerWidth,innerHeight);
    this.renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));
    this.renderer.shadowMap.enabled=true;
    this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace=THREE.SRGBColorSpace;
    this.renderer.toneMapping=THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure=1.15;
    document.body.appendChild(this.renderer.domElement);
    this.clock=new THREE.Clock();
    this.keys={};
    this.pointerLocked=false;
    this.yaw=0; this.pitch=.28;
    this.hud=new HUD();
    this.world=createWorld(this.scene);
    this.player=createPlayer(this.scene);
    this.combat=new CombatSystem(this);
    this.enemies=[new Enemy(this.scene,new THREE.Vector3(0,0,-12),this)];
    this.bindInput();
    window.addEventListener('resize',()=>this.resize());
  }
  bindInput(){
    window.addEventListener('keydown',e=>{this.keys[e.code]=true;if(e.code==='Space')e.preventDefault();});
    window.addEventListener('keyup',e=>this.keys[e.code]=false);
    this.renderer.domElement.addEventListener('click',()=>{if(!this.pointerLocked)this.renderer.domElement.requestPointerLock?.();});
    document.addEventListener('pointerlockchange',()=>this.pointerLocked=document.pointerLockElement===this.renderer.domElement);
    document.addEventListener('mousemove',e=>{if(this.pointerLocked){this.yaw-=e.movementX*.0022;this.pitch=THREE.MathUtils.clamp(this.pitch-e.movementY*.0018,-.15,.8);}});
    window.addEventListener('mousedown',e=>{if(e.button===0)this.combat.attack();});
    window.addEventListener('keydown',e=>{
      if(e.code==='ShiftLeft'||e.code==='ShiftRight')this.combat.dodge();
      if(e.code==='KeyQ')this.combat.skill();
      if(e.code==='KeyE')this.combat.ultimate();
    });
  }
  start(){this.animate();}
  animate(){
    requestAnimationFrame(()=>this.animate());
    const dt=Math.min(this.clock.getDelta(),.033);
    updatePlayer(this.player,dt,this.keys,this);
    this.combat.update(dt);
    for(const enemy of this.enemies)enemy.update(dt,this.player);
    this.updateCamera();
    this.world.update(dt);
    this.hud.update(this.player,this.enemies[0],this.combat);
    this.renderer.render(this.scene,this.camera);
  }
  updateCamera(){
    const target=this.player.group.position.clone().add(new THREE.Vector3(0,1.45,0));
    const offset=new THREE.Vector3(Math.sin(this.yaw)*5,2.2+this.pitch*3,Math.cos(this.yaw)*5);
    this.camera.position.lerp(target.add(offset),.12);
    this.camera.lookAt(this.player.group.position.clone().add(new THREE.Vector3(0,1.25,0)));
  }
  resize(){this.camera.aspect=innerWidth/innerHeight;this.camera.updateProjectionMatrix();this.renderer.setSize(innerWidth,innerHeight);}
}
function sixty(){return 60;}
