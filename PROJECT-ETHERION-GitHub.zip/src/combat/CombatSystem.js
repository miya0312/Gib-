import * as THREE from 'three';

export class CombatSystem{
  constructor(game){this.game=game;this.cooldowns={skill:0,ultimate:0};this.attackCooldown=0;this.combo=0;this.comboWindow=0;this.hitFlash=0;}
  attack(){
    if(this.attackCooldown>0||this.game.player.dodgeTime>0)return;
    this.combo=this.comboWindow>0?(this.combo%5)+1:1;
    this.comboWindow=.72;this.attackCooldown=.34;
    const p=this.game.player; p.attackTime=.28;
    const forward=new THREE.Vector3(Math.sin(this.game.yaw),0,-Math.cos(this.game.yaw));
    const target=this.game.enemies[0];
    if(target&&!target.dead){
      const delta=target.group.position.clone().sub(p.group.position);const dist=delta.length();
      if(dist<3.3&&forward.dot(delta.normalize())>.15){
        const damage=[10,11,13,16,21][this.combo-1];
        target.takeDamage(damage,10+this.combo*3);
        p.ultimate=Math.min(100,p.ultimate+5);
        this.toast(['FIRST STRIKE','CROSS SLASH','RISING EDGE','ARC BREAK','FINISHER'][this.combo-1]);
      }
    }
  }
  dodge(){
    const p=this.game.player;if(p.stamina<20||p.dodgeTime>0)return;
    p.stamina-=20;p.dodgeTime=.48;
    p.velocity.y=Math.max(p.velocity.y,0);
    this.toast('PERFECT DODGE WINDOW');
  }
  skill(){
    if(this.cooldowns.skill>0)return;this.cooldowns.skill=4;
    const p=this.game.player;const enemy=this.game.enemies[0];
    if(enemy&&!enemy.dead&&enemy.group.position.distanceTo(p.group.position)<5){enemy.takeDamage(28,28);p.ultimate=Math.min(100,p.ultimate+12);}
    this.toast('AETHER LANCE');
  }
  ultimate(){
    const p=this.game.player;if(p.ultimate<100){this.toast('ULTIMATE NOT READY');return;}
    p.ultimate=0;const enemy=this.game.enemies[0];
    if(enemy&&!enemy.dead&&enemy.group.position.distanceTo(p.group.position)<8)enemy.takeDamage(85,60);
    this.toast('ETHER NOVA');
  }
  update(dt){this.attackCooldown=Math.max(0,this.attackCooldown-dt);this.comboWindow=Math.max(0,this.comboWindow-dt);this.cooldowns.skill=Math.max(0,this.cooldowns.skill-dt);this.cooldowns.ultimate=Math.max(0,this.cooldowns.ultimate-dt);}
  toast(t){const el=document.getElementById('toast');el.textContent=t;el.style.opacity=1;clearTimeout(this.toastTimer);this.toastTimer=setTimeout(()=>el.style.opacity=0,850);}
}
