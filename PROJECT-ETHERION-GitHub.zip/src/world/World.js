import * as THREE from 'three';

export function createWorld(scene){
  const hemi=new THREE.HemisphereLight(0xd9efff,0x40513c,2.0);scene.add(hemi);
  const sun=new THREE.DirectionalLight(0xffedcf,3.0);sun.position.set(-35,55,25);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);sun.shadow.camera.left=-55;sun.shadow.camera.right=55;sun.shadow.camera.top=55;sun.shadow.camera.bottom=-55;scene.add(sun);
  const groundGeo=new THREE.PlaneGeometry(220,220,100,100);groundGeo.rotateX(-Math.PI/2);
  const p=groundGeo.attributes.position;
  for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getZ(i);p.setY(i,Math.sin(x*.075)*.55+Math.cos(z*.09)*.45+Math.sin((x+z)*.035)*.8);}
  groundGeo.computeVertexNormals();
  const ground=new THREE.Mesh(groundGeo,new THREE.MeshStandardMaterial({color:0x587d59,roughness:1}));ground.receiveShadow=true;scene.add(ground);
  const hillMat=new THREE.MeshStandardMaterial({color:0x476a55,roughness:1});
  for(let i=0;i<34;i++){const a=i/34*Math.PI*2,r=48+(i%4)*7,h=8+(i%5)*3;const m=new THREE.Mesh(new THREE.ConeGeometry(8,h,7),hillMat);m.position.set(Math.cos(a)*r,h/2-1,Math.sin(a)*r);m.scale.z=1.5;m.receiveShadow=true;scene.add(m);}
  const trunkMat=new THREE.MeshStandardMaterial({color:0x4a3828}),leafMat=new THREE.MeshStandardMaterial({color:0x2d684e,roughness:.9});
  for(let i=0;i<85;i++){
    const a=i*2.399,r=13+(i%13)*2.5,x=Math.cos(a)*r,z=Math.sin(a)*r;
    if(Math.abs(x)<5&&z<5&&z>-20)continue;
    const tree=new THREE.Group();
    const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.18,.32,2.7,7),trunkMat);trunk.position.y=1.35;trunk.castShadow=true;tree.add(trunk);
    const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(1.35+(i%3)*.25,1),leafMat);crown.position.y=3.1;crown.scale.set(1,1.15,.9);crown.castShadow=true;tree.add(crown);
    tree.position.set(x,0,z);scene.add(tree);
  }
  // Ancient stone fragments create a recognizable landmark.
  const stoneMat=new THREE.MeshStandardMaterial({color:0x82918e,roughness:.85});
  for(let i=0;i<7;i++){const pillar=new THREE.Mesh(new THREE.BoxGeometry(1.1,5+(i%3),1.1),stoneMat);pillar.position.set(10+i*1.6,2.5,-25+(i%2)*2);pillar.rotation.z=(i%2)*.08;pillar.castShadow=true;scene.add(pillar);}
  const platform=new THREE.Mesh(new THREE.CylinderGeometry(5.5,6,1,12),new THREE.MeshStandardMaterial({color:0x687a79,roughness:.8}));platform.position.set(14,0.1,-25);platform.castShadow=true;scene.add(platform);
  return {update(){}};
}
