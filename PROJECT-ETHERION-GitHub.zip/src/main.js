import * as THREE from 'three';
import { Game } from './core/Game.js';

const game = new Game();
game.start();
