import * as THREE from 'three';

export class Enemy{
  constructor(scene,pos,game){
    this.game=game;this.group=new THREE.Group();this.group.position.copy(pos);scene.add(this.group);
    const shell=new THREE.MeshStandardMaterial({color:0x293747,metalness:.55,roughness:.4});
    const glow=new THREE.MeshStandardMaterial({color:0xe85f9b,emissive:0x9d174d,emissiveIntensity:1.8});
    const body=new THREE.Mesh(new THREE.IcosahedronGeometry(.78,1),shell);body.position.y=1.05;body.scale.set(.8,1.2,.65);body.castShadow=true;this.group.add(body);
    const head=new THREE.Mesh(new THREE.SphereGeometry(.38,14,12),shell);head.position.y=2.05;head.castShadow=true;this.group.add(head);
    for(const s of [-1,1]){const eye=new THREE.Mesh(new THREE.SphereGeometry(.09,10,8),glow);eye.position.set(s*.17,2.08,.32);this.group.add(eye);}
    for(let i=0;i<3;i++){const spike=new THREE.Mesh(new THREE.ConeGeometry(.16,.7,6),shell);spike.position.set((i-1)*.38,1.55,-.35);spike.rotation.x=-.6;this.group.add(spike);}
    this.hp=120;this.maxHp=120;this.poise=100;this.maxPoise=100;this.dead=false;this.attackTimer=1.5;this.state='idle';this.hitTimer=0;
  }
  takeDamage(dmg,poise){
    if(this.dead)return;this.hp=Math.max(0,this.hp-dmg);this.poise=Math.max(0,this.poise-poise);this.hitTimer=.14;
    if(this.poise===0){this.state='stagger';this.stagger=.9;this.poise=55;}
    if(this.hp===0){this.dead=true;this.group.visible=false;this.game.combat.toast('TARGET ELIMINATED');}
  }
  update(dt,player){
    if(this.dead)return;
    const d=player.group.position.clone().sub(this.group.position);const dist=d.length();
    this.group.rotation.y=Math.atan2(d.x,d.z);
    if(this.hitTimer>0){this.hitTimer-=dt;this.group.position.y=Math.sin(this.hitTimer*25)*.08;}
    if(this.state==='stagger'){this.stagger-=dt;if(this.stagger<=0)this.state='idle';return;}
    if(dist>2.25&&dist<24){d.y=0;d.normalize();this.group.position.addScaledVector(d,dt*2.3);this.state='chase';}
    else if(dist<=2.25){this.state='attack';this.attackTimer-=dt;if(this.attackTimer<=0){this.attackTimer=2.1;if(player.dodgeTime<=.12){player.hp=Math.max(0,player.hp-9);this.game.combat.toast('DAMAGE TAKEN');}}}
    else this.state='idle';
  }
}
