import * as THREE from 'three';

export function createPlayer(scene){
  const group=new THREE.Group();scene.add(group);
  const skin=new THREE.MeshStandardMaterial({color:0xf0c8b5,roughness:.75});
  const hair=new THREE.MeshStandardMaterial({color:0x8ed7e9,roughness:.48,metalness:.05});
  const dark=new THREE.MeshStandardMaterial({color:0x182638,roughness:.7});
  const cloth=new THREE.MeshStandardMaterial({color:0xe8edf2,roughness:.8});
  const accent=new THREE.MeshStandardMaterial({color:0x69d9e7,emissive:0x123e48,roughness:.35});
  const make=(geo,mat,pos,parent=group)=>{const m=new THREE.Mesh(geo,mat);m.position.set(...pos);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;};
  const torso=new THREE.Group();torso.position.y=1.05;group.add(torso);
  make(new THREE.CapsuleGeometry(.34,.68,5,10),cloth,[0,0,0],torso);
  make(new THREE.SphereGeometry(.36,16,12),skin,[0,.67,0],torso);
  make(new THREE.SphereGeometry(.39,16,12),hair,[0,.94,-.03],torso);
  // Front fringe and side locks; intentionally separate meshes for later replacement.
  for(let i=0;i<5;i++){const bang=make(new THREE.ConeGeometry(.105,.62,7),hair,[-.25+i*.12,.73,.27],torso);bang.rotation.x=-.25;bang.rotation.z=(i-2)*.12;}
  for(const s of [-1,1]){const lock=make(new THREE.CapsuleGeometry(.075,.78,4,8),hair,[s*.34,.27,.02],torso);lock.rotation.z=s*.12;}
  make(new THREE.SphereGeometry(.045,10,8),dark,[-.13,.65,.31],torso);
  make(new THREE.SphereGeometry(.045,10,8),dark,[.13,.65,.31],torso);
  make(new THREE.TorusGeometry(.38,.035,6,24),accent,[0,1.08,0],torso).rotation.x=Math.PI/2;
  const limbs=[];
  for(const s of [-1,1]){
    const arm=new THREE.Group();arm.position.set(s*.43,.38,0);torso.add(arm);
    make(new THREE.CapsuleGeometry(.105,.55,4,8),cloth,[0,-.28,0],arm);limbs.push(arm);
    const leg=new THREE.Group();leg.position.set(s*.18,-.45,0);group.add(leg);
    make(new THREE.CapsuleGeometry(.14,.66,4,8),dark,[0,-.36,0],leg);limbs.push(leg);
    make(new THREE.BoxGeometry(.27,.14,.42),accent,[0,-.72,.09],leg);
  }
  // A slim energy blade attached to the right hand.
  const blade=new THREE.Mesh(new THREE.BoxGeometry(.075,.95,.12),new THREE.MeshStandardMaterial({color:0x8cefff,emissive:0x3bbedb,emissiveIntensity:1.8}));blade.position.set(.62,.55,.1);blade.rotation.z=-.25;torso.add(blade);
  group.position.set(0,0,0);
  return {group,torso,limbs,blade,hp:100,maxHp:100,stamina:100,maxStamina:100,velocity:new THREE.Vector3(),onGround:true,animTime:0,attackTime:0,dodgeTime:0,ultimate:0};
}

// Frame-based controller: acceleration, gravity and ground clamping.
const _forward=new THREE.Vector3(),_right=new THREE.Vector3(),_move=new THREE.Vector3();
const _ray=new THREE.Raycaster();
export function updatePlayer(player,dt,keys,game){
  const g=player.group;
  _forward.set(Math.sin(game.yaw),0,-Math.cos(game.yaw));
  _right.set(_forward.z,0,-_forward.x);
  _move.set(0,0,0);
  if(keys.KeyW)_move.add(_forward);
  if(keys.KeyS)_move.sub(_forward);
  if(keys.KeyD)_move.add(_right);
  if(keys.KeyA)_move.sub(_right);
  if(_move.lengthSq()>0){
    _move.normalize();player.velocity.x=THREE.MathUtils.damp(player.velocity.x,_move.x*7.2,12,dt);player.velocity.z=THREE.MathUtils.damp(player.velocity.z,_move.z*7.2,12,dt);
    g.rotation.y=Math.atan2(_move.x,_move.z);
  }else{player.velocity.x=THREE.MathUtils.damp(player.velocity.x,0,9,dt);player.velocity.z=THREE.MathUtils.damp(player.velocity.z,0,9,dt);}
  if(keys.Space&&player.onGround){player.velocity.y=8.2;player.onGround=false;}
  if(player.dodgeTime>0){player.dodgeTime=Math.max(0,player.dodgeTime-dt);player.velocity.x+=Math.sin(g.rotation.y)*18*dt;player.velocity.z+=Math.cos(g.rotation.y)*18*dt;}
  player.velocity.y-=19*dt;
  g.position.x+=player.velocity.x*dt;g.position.y+=player.velocity.y*dt;g.position.z+=player.velocity.z*dt;
  if(g.position.y<=0){g.position.y=0;player.velocity.y=0;player.onGround=true;}
  player.stamina=Math.min(player.maxStamina,player.stamina+dt*18);
  player.animTime+=dt;
  const moving=_move.lengthSq()>0;
  const swing=player.attackTime>0?Math.sin((.28-player.attackTime)/.28*Math.PI)*.9:0;
  player.attackTime=Math.max(0,player.attackTime-dt);
  player.torso.rotation.x= moving?Math.sin(player.animTime*10)*.035:0;
  player.limbs[0].rotation.x=moving?Math.sin(player.animTime*10)*.55:swing;
  player.limbs[1].rotation.x=moving?Math.sin(player.animTime*10+Math.PI)*.55:0;
  player.limbs[2].rotation.x=moving?Math.sin(player.animTime*10+Math.PI)*.5:0;
  player.limbs[3].rotation.x=moving?Math.sin(player.animTime*10)*.5:0;
}
