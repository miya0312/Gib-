export class HUD{
  update(player,enemy,combat){
    const set=(id,v)=>{const el=document.getElementById(id);if(el)el.style.width=`${Math.max(0,Math.min(100,v))}%`;};
    set('hp-fill',player.hp/player.maxHp*100);set('stamina-fill',player.stamina/player.maxStamina*100);
    document.getElementById('hp-text').textContent=`${Math.ceil(player.hp)} / ${player.maxHp}`;
    document.getElementById('stamina-text').textContent=`${Math.ceil(player.stamina)} / ${player.maxStamina}`;
    const panel=document.getElementById('enemy-panel');
    if(enemy&&!enemy.dead){panel.classList.add('visible');set('enemy-hp-fill',enemy.hp/enemy.maxHp*100);set('enemy-poise-fill',enemy.poise/enemy.maxPoise*100);}
    else panel.classList.remove('visible');
  }
}
